// Using webkit speech recongnition

var SpeechRecognition = window.webkitSpeechRecognition;
  
var recognition = new SpeechRecognition();

// Making variables 

var Textbox = $('#textbox');

var Content = '';

recognition.onresult = function(event) {
  
  // recongnize speech word by word

  var current = event.resultIndex;

  // makes an array with current words 
  
  var transcript = event.results[current][0].transcript;
 
    Content += transcript;
    Textbox.val(Content);
  
};

// Recognition function start 

// Adding lines to pre existing content 

$('#start-btn').on('click', function() {
  if (Content.length) {
    Content += ' ';
  }
  recognition.start();
});


// Clearing the textbox 

$('#clear-btn').on('click', function() {
  if (Content.length) {
    Content = ' ';
  }
  
});
